<template>
  <main>
    <oyun></oyun>
  </main>
</template>


<script setup>
import Oyun from '@/pages/oyun.vue'
</script>


<style scoped>

</style>
