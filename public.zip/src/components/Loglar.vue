<template>
  <div>
    <h3>LOGLAR</h3>

    <p>{{props.olay.kim}} {{props.olay.kime}} {{props.olay.kaçVurdu}} vurdu</p>

  </div>
</template>

<script setup>

var props = defineProps({
  olay:{
    type: Object,
    required: true
  }
})

</script>

<style lang="scss" scoped></style>
